const { createShare, getShare, qrReader } = require("./controller.share")
const router = require("express").Router();

router.post("/", createShare);
router.get("/", getShare);
router.post("/qr-reader", qrReader);
module.exports = router;
