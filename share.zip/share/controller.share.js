const Share = require("./service.share");
var nodemailer = require('nodemailer');
const Email = require("../../config/email.json");
const path = require('path');
const hostName = "https://plunge.webarttechnology.co.in";

const fs = require('fs');
const Jimp = require("jimp");
const jsQR = require("jsqr");


const createShare = async (req, res) => {
    const body = req.body    
    console.log(req.file)
    return false;
    try{
        const share = await Share.create({
            userId: body.userId,
            emailId: body.emailId,
            image: req.file.path
        })

        
        //Send Email 
    

        to = body.emailId
        subject = "Invited"
        emailbody = "Scan and join with us."
        var transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
              user: Email.emailId,
              pass: Email.password
            }
          });
          
          var mailOptions = {
            from: 'Plunge <'+Email.emailId+'>',
            to: body.emailId,
            subject:subject,
            text:emailbody,
            attachments: [{
                filename: req.file.filename,
                path: hostName+'/'+req.file.path
            }]
          };

          transporter.sendMail(mailOptions, function(error, info){
            if (error) {
                  return res.status(409).json({
                    success: 0,
                    msg: error
                })
            }else{
                
                return res.status(200).json({
                    success: true,
                    data: share,
                    message: "We have send a email with a attached to your entered Email ID"
                })
            }
          });

         
    }catch(err){
        return res.status(409).json({
            success: 0,
            msg: err
        })
    }
   
}

const getShare = async (req, res) => {
    try{
        const share = await Share.findAll();

        return res.status(200).json({
            success: 1,
            data: share
        })
    }catch(err){
        return res.status(409).json({
            success: 0,
            data: err
        })
    }
}

const qrReader = async (req, res) => {  
    
    let filePath = 'qrimages';
    const imagename = Date.now()+'.jpeg';
    const imagepath = filePath+'/'+Date.now()+'.jpeg'; 

    let buffer = Buffer.from(req.body.image.split(',')[1], 'base64');
    fs.writeFileSync(path.join(__dirname, imagepath), buffer);
    const qrpath = `${__dirname}/${imagepath}`;
   
    var cbuffer = fs.readFileSync(qrpath);   
    Jimp.read(cbuffer, async function(err, image) {
    const value = jsQR(image.bitmap.data, image.bitmap.width, image.bitmap.height); 
    const str = value.data;
    const newStr = str.replace('"', '');
    const rnewStr = newStr.replace('"', ''); 

    return res.status(200).json({
        success: 1,
        data: parseInt(rnewStr)
    })
   })
}

module.exports = {
    createShare: createShare,
    getShare: getShare,
    qrReader: qrReader
}