const Sequelize = require('sequelize');
const sequelize = require('../../config/database');

module.exports = sequelize.define('shares', {

    id: {
        type: Sequelize.INTEGER(11),
        primaryKey:true,
        autoIncrement: true 
    },
    userId: {
        type: Sequelize.INTEGER(11),
        validator: {
            notEmpty: { args: true, msg: "Registered user id required"}
        },
        allowNull: false
    },
    emailId: {
        type: Sequelize.STRING(200),
        validator: {
            notEmpty: {args: true, msg: "Email ID must be required!!"}
        },
        allowNull: false
    },
    image: {
        type: Sequelize.STRING(200),
        validator: {
            notEmpty: { args: true, msg: "Image file must be required!"}
        },
        allowNull: false
    }
})